package com.example.demo_javafx.service;

import java.sql.*;
import java.util.List;

import static com.example.demo_javafx.constant.DbConstant.*;

public class SiyoServices {
    public static ResultSet getAllSiyo() throws SQLException {
        // return all records of iv_siyo
        String SELECT_QUERY = "SELECT * FROM iv_siyo";
        Connection conn = DriverManager.getConnection(DATABASE, USERNAME, PASSWORD);
        PreparedStatement ps = conn.prepareStatement(SELECT_QUERY);
        return ps.executeQuery();
    }

    public static ResultSet getSiyoByShohinCode(String shohinCode) throws SQLException {
        // return all records of iv_siyo with SHOHIN_CD input
        String SELECT_QUERY = "SELECT * FROM iv_siyo WHERE SHOHIN_CD = ?";
        Connection conn = DriverManager.getConnection(DATABASE, USERNAME, PASSWORD);
        PreparedStatement ps = conn.prepareStatement(SELECT_QUERY);
        ps.setString(1, shohinCode);
        return ps.executeQuery();
    }

    public static ResultSet finalResult(List<String> siyo_ids, List<String> juto_codes) throws SQLException{
        // return final results (SIYO_ID, POINT)
        String SELECT_QUERY = """
                SELECT SIYO_ID, SUM(WEIGHTING) AS POINT
                FROM iv_sych join iv_juto_weight on iv_sych.JUTO_CD = iv_juto_weight.JUTO_CD
                WHERE SIYO_ID IN (?) AND JUTO_CD IN (?)
                GROUP BY SIYO_ID;
                """;
        Connection conn = DriverManager.getConnection(DATABASE, USERNAME, PASSWORD);
        PreparedStatement ps = conn.prepareStatement(SELECT_QUERY);
        ps.setString(1, String.join(",", siyo_ids));
        ps.setString(2, String.join(",", juto_codes));

        return ps.executeQuery();
    }
}

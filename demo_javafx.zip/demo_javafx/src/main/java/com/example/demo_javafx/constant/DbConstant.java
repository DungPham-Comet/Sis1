package com.example.demo_javafx.constant;

public class DbConstant {
    public static final String DATABASE = "jdbc:mysql://localhost:3306/";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "admin";
}

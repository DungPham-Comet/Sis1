package com.example.demo_javafx;

import com.example.demo_javafx.model.Product;
import com.example.demo_javafx.model.Result;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HelloController {

    private List<Result> processedResults;

    @FXML
    private Button findBtn;

    @FXML
    private AnchorPane basePane;

    @FXML
    private Button chooseFileBtn;

    @FXML
    private TextField filePath;

    @FXML
    void chooseFile(ActionEvent event) throws ParserConfigurationException, IOException, SAXException {
        // Create Filechooser
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose File");

        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("XML Files", "*.xml")
        );

        Stage stage = (Stage) chooseFileBtn.getScene().getWindow();
        File selectedFile = fileChooser.showOpenDialog(stage);

        if (selectedFile != null) {
            filePath.setText(selectedFile.getAbsolutePath());
            List<Product> products = new ArrayList<Product>();
            // Read input file - Extract data

            File inputFile = new File(selectedFile.getAbsolutePath());
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            NodeList nList = doc.getElementsByTagName("user");

            for (int i = 0; i < nList.getLength(); i++) {
                String koujiNumber = doc.getElementsByTagName("kouji_number").item(i).getTextContent();
                int spaceFinderId = Integer.parseInt(doc.getElementsByTagName("spaceFinderId").item(i).getTextContent());
                String shohinCode = doc.getElementsByTagName("shohin_code").item(i).getTextContent();
                String note = doc.getElementsByTagName("note").item(i).getNodeValue();
                List<String> jutoCodes = new ArrayList<String>();
                NodeList jutoCodeList = doc.getElementsByTagName("juto_code");
                for (int j = 0; j < jutoCodeList.getLength(); j++) {
                    jutoCodes.add(jutoCodeList.item(j).getTextContent());
                }
                Product product = new Product(koujiNumber, spaceFinderId, shohinCode, jutoCodes, note);
                products.add(product);
//                Collections.sort(products, new Comparator<Product>() {
//                    @Override
//                    public int compare(Product s1, Product s2) {
//                        return Double.compare(s2.point, s1.point); // Sắp xếp giảm dần
//                    }
//                });
            }

            // Handle query - Create Result object - Sort

            // Write to output file

            try {
                PrintWriter writer = new PrintWriter("src/main/java/com/example/demo_javafx/data/output.csv", "UTF-8");
                writer.println("kouji_number,spaceFinderId,shohin_code,juto_code,note");
                for (Product product : products) {
                    writer.print(product.getKoujiNumber() + ",");
                    writer.print(product.getSpaceFinderId() + ",");
                    writer.print(product.getShohinCode() + ",");
                    for (String jutoCode : product.getJutoCodes()) {
                        writer.print(jutoCode + " ");
                    }
                    writer.print(",");
                    writer.println(product.getNote());
                }
                System.out.println("Created output.csv");
                writer.close();

            } catch (FileNotFoundException | UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            }

        } else {
            filePath.setText("No file selected");
        }
    }

    @FXML
    public void switchToResult(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("result.fxml"));
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}

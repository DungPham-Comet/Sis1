package com.example.demo_javafx.model;

import java.util.List;

public class Product {
    private String koujiNumber;
    private int spaceFinderId;
    private String shohinCode;
    private List<String> jutoCodes;
    private String note;

    public Product() {
    }

    public Product(String koujiNumber, int spaceFinderId, String shohinCode, List<String> jutoCodes, String note) {
        this.koujiNumber = koujiNumber;
        this.spaceFinderId = spaceFinderId;
        this.shohinCode = shohinCode;
        this.jutoCodes = jutoCodes;
        this.note = note;
    }

    public String getKoujiNumber() {
        return koujiNumber;
    }

    public void setKoujiNumber(String koujiNumber) {
        this.koujiNumber = koujiNumber;
    }

    public int getSpaceFinderId() {
        return spaceFinderId;
    }

    public void setSpaceFinderId(int spaceFinderId) {
        this.spaceFinderId = spaceFinderId;
    }

    public String getShohinCode() {
        return shohinCode;
    }

    public void setShohinCode(String shohinCode) {
        this.shohinCode = shohinCode;
    }

    public List<String> getJutoCodes() {
        return jutoCodes;
    }

    public void setJutoCodes(List<String> jutoCodes) {
        this.jutoCodes = jutoCodes;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}

package com.example.demo_javafx;

import com.example.demo_javafx.model.Result;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ResultDisplayController implements Initializable {

    public static final int ROWS_PER_PAGE = 10;

    private List<Result> processedResults;

    @FXML
    private AnchorPane basePane;

    @FXML
    private Button returnToHomeBtn;

    @FXML
    private TableColumn indexColumn;

    @FXML
    private TableColumn<Result, String> koujiNumColumn;

    @FXML
    private Pagination pagination;

    @FXML
    private TableColumn<Result, Integer> pointColumn;

    @FXML
    private TableColumn<Result, String> shohinCodeColumn;

    @FXML
    private TableView<Result> tableView;

    public void setProcessedResults(List<Result> processedResults) {
        this.processedResults = processedResults;
        if (pagination != null) {
            pagination.setPageCount((int) Math.ceil((double) processedResults.size() / ROWS_PER_PAGE));
            pagination.setPageFactory(this::createTableView);
        }
    }

    @FXML
    public void returnHome(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void readResult(List<Result> results,String path) {
        try (BufferedReader reader = Files.newBufferedReader(Path.of(path))) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                String[] data = line.split(",");
                Result result = new Result(data[0], data[1], Integer.parseInt(data[2]));
                results.add(result);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(java.net.URL location, java.util.ResourceBundle resources) {
        // read result file to create processedResults
        processedResults = new ArrayList<Result>();
        readResult(processedResults,"src/main/java/com/example/demo_javafx/data/sample_true_output.csv");

        int pageMod = processedResults.size() % ROWS_PER_PAGE;
        if (pageMod != 0)
            pagination.setPageCount(processedResults.size() / ROWS_PER_PAGE + 1);
        else pagination.setPageCount(processedResults.size() / ROWS_PER_PAGE);
        pagination.setMaxPageIndicatorCount(3);
        pagination.setPageFactory(this::createTableView);
    }

    public Node createTableView(int pageIndex) {
        indexColumn.setCellValueFactory((Callback<TableColumn.CellDataFeatures<Result, Result>, ObservableValue<Result>>) p -> new ReadOnlyObjectWrapper(p.getValue()));
        indexColumn.setCellFactory(new Callback<TableColumn<Result, Result>, TableCell<Result, Result>>() {
            @Override
            public TableCell<Result, Result> call(TableColumn<Result, Result> param) {
                return new TableCell<Result, Result>() {
                    @Override
                    protected void updateItem(Result item, boolean empty) {
                        super.updateItem(item, empty);

                        if (this.getTableRow() != null && item != null) {
                            setText(this.getTableRow().getIndex() + 1 + pageIndex * ROWS_PER_PAGE + "");
                        } else {
                            setText("");
                        }
                    }
                };
            }
        });

        indexColumn.setSortable(false);
        koujiNumColumn.setCellValueFactory(new PropertyValueFactory<Result, String>("koujiNum"));
        shohinCodeColumn.setCellValueFactory(new PropertyValueFactory<Result, String>("shohinCode"));
        pointColumn.setCellValueFactory(new PropertyValueFactory<Result, Integer>("point"));

        int lastIndex = 0;
        int displace = processedResults.size() % ROWS_PER_PAGE;
        if (displace > 0) {
            lastIndex = processedResults.size() / ROWS_PER_PAGE;
        } else {
            lastIndex = processedResults.size() / ROWS_PER_PAGE - 1;
        }

        if (processedResults.isEmpty())
            tableView.setItems(FXCollections.observableArrayList(processedResults));
        else{
            if (lastIndex == pageIndex && displace > 0) {
                tableView.setItems(FXCollections.observableArrayList(processedResults.subList(pageIndex * ROWS_PER_PAGE, pageIndex * ROWS_PER_PAGE + displace)));
            } else {
                tableView.setItems(FXCollections.observableArrayList(processedResults.subList(pageIndex * ROWS_PER_PAGE, pageIndex * ROWS_PER_PAGE + ROWS_PER_PAGE)));
            }
        }
        return tableView;
    }
}
